
public class Main {
    public static void main(String[] args) {
        ArithmeticExample.Arithmetic();
        System.out.println("=============================================");
        CharacterPrinter.CharacterPrinting();
        System.out.println("=============================================");
        CharacterCreator.CharacterCreation();
        System.out.println("=============================================");
        DragonSlayer.DragonSlaying();
        System.out.println("=============================================");
        Treasure.MakeTreasure();
        System.out.println("=============================================");

    }
}