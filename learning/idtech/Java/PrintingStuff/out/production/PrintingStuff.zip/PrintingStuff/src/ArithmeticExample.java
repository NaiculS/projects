public class ArithmeticExample {
    public static void Arithmetic(){
        int Number1=2;
        int Number2=100;
        Number1+=10;
        Number1--;
        Number2*=Number1;
        Number2++;
        System.out.println("Number 1: " + Number1);
        System.out.println("Number 2: " + Number2);
    }
    public static void main(String[] args) {
        int Number1=2;
        int Number2=100;
        Number1+=10;
        Number1--;
        Number2*=Number1;
        Number2++;
        System.out.println("Number 1: " + Number1);
        System.out.println("Number 2: " + Number2);
    }
}
