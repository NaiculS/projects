public class CharacterPrinter {
    public static void CharacterPrinting(){
        //Declares level value
        int level;
        level=1;
        System.out.println("Level: " + level);
        //Declares health value
        double health;
        health=12.5;
        System.out.println("Health: " + health);
        health=9.0;
        System.out.println("Updated Health: " + health);
        //Declares name
        String name;
        name="Mallis";
        System.out.println("Character Name: " + name);
    }
    public static void main(String[] args) {
        //Declares level value
        int level;
        level=1;
        System.out.println("Level: " + level);
        //Declares health value
        double health;
        health=12.5;
        System.out.println("Health: " + health);
        health=9.0;
        System.out.println("Updated Health: " + health);
        //Declares name
        String name;
        name="Mallis";
        System.out.println("Character Name: " + name);
    }
}

